# 🚀 Руководство по запуску Alfa Campaign Manager в Google Colab

Google Colab — это отличный способ запустить проект без установки Python и зависимостей на свой компьютер.

---

## 1. Подготовка

### Шаг 1: Загрузка проекта
1.  Перейдите на [https://colab.research.google.com](https://colab.research.google.com) и создайте новый Notebook.
2.  Загрузите файл **`alfa-campaign-manager-v2.0-COMMERCIAL.zip`** в корневую папку вашего Colab Notebook.

### Шаг 2: Распаковка проекта
Вставьте и выполните следующий код в первой ячейке:

```python
# Распаковка архива
!unzip -q alfa-campaign-manager-v2.0-COMMERCIAL.zip
# Переход в папку проекта
%cd alfa-campaign-manager
```

---

## 2. Установка зависимостей

### Шаг 3: Установка Python пакетов
Вставьте и выполните следующий код во второй ячейке:

```python
# Установка всех необходимых зависимостей
!pip install -q -r requirements.txt
# Установка pyngrok для создания публичного URL
!pip install pyngrok
```

---

## 3. Настройка переменных окружения

### Шаг 4: Ввод API ключей
Вставьте и выполните следующий код в третьей ячейке. **Обязательно замените `YOUR_...` на ваши реальные ключи!**

```python
import os

# !!! ВАЖНО: Замените YOUR_... на ваши реальные ключи !!!

# Telegram API (получить на https://my.telegram.org)
os.environ['TELEGRAM_API_ID'] = 'YOUR_API_ID'
os.environ['TELEGRAM_API_HASH'] = 'YOUR_API_HASH'
os.environ['TELEGRAM_PHONE_NUMBER'] = 'YOUR_PHONE_NUMBER' # Например, +79991234567

# Telegram Bot Token (получить у @BotFather)
os.environ['TELEGRAM_BOT_TOKEN'] = 'YOUR_BOT_TOKEN'

# AI API (получить на https://makersuite.google.com/app/apikey или https://console.groq.com)
os.environ['GEMINI_API_KEY'] = 'YOUR_GEMINI_KEY'
os.environ['GROQ_API_KEY'] = 'YOUR_GROQ_KEY'

# База данных (используем SQLite по умолчанию)
os.environ['DATABASE_URL'] = 'sqlite:///./alfa.db'

print("✅ Переменные окружения установлены.")
```

---

## 4. Запуск приложения и получение ссылки

### Шаг 5: Запуск FastAPI с публичным доступом
Вставьте и выполните следующий код в четвертой ячейке. Этот код запустит приложение и создаст публичную ссылку через **ngrok**.

```python
from pyngrok import ngrok
import subprocess
import time

# 1. Запуск FastAPI в фоновом режиме
# Используем uvicorn для запуска main.py
process = subprocess.Popen(["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"],
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)

print("🚀 FastAPI запущен на порту 8000...")
time.sleep(5) # Даем время на запуск

# 2. Создание публичного туннеля через ngrok
# Если у вас есть токен ngrok, введите его здесь: ngrok.set_auth_token("YOUR_NGROK_TOKEN")
try:
    public_url = ngrok.connect(8000)
    print(f"✅ Приложение доступно по публичному адресу:")
    print(f"   {public_url}")
    print(f"   {public_url}/setup")
    print("\n⚠️ ВАЖНО: Не закрывайте эту ячейку, пока работаете с приложением!")
    
    # Оставляем процесс работать, чтобы не закрылся Colab
    while True:
        time.sleep(1)

except Exception as e:
    print(f"❌ Ошибка при запуске ngrok: {e}")
    print("Попробуйте перезапустить ячейку или проверьте, что порт 8000 свободен.")
    
finally:
    # Очистка ngrok туннеля при остановке
    ngrok.kill()
    process.terminate()
```

---

## 5. Использование

1.  Перейдите по публичной ссылке, которую выдаст скрипт (например, `https://abcdef12345.ngrok.io`).
2.  При первом запуске Telegram попросит вас ввести код подтверждения.
3.  После ввода кода сессия будет сохранена, и вы сможете использовать приложение.

**Важно:** Colab сессия будет активна, пока вы не закроете вкладку или не остановите ячейку. Для постоянной работы рекомендуется VPS.
